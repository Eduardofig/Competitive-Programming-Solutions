#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>

int max(const int a, const int b);
void *safe_realloc(void *ptr, size_t mem_size);

#endif
